import React from "react";
import { useNavigate } from "react-router-dom";

function Main(){
  const navigate = useNavigate();

  return(
    <>
      <h1 onClick={() => navigate('/mypage')}>메인페이지입니다</h1>
    </>
  )
}

export default Main;